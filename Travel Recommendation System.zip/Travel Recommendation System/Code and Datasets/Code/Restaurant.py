import pandas as pd
import numpy as np
import warnings
import ast
import networkx as nx
import streamlit as st
from scipy.stats import pearsonr
from sklearn.metrics import jaccard_score
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.metrics import pairwise_distances
import random
import string
from surprise import SVD
from surprise import Dataset
from surprise import Reader
from surprise.model_selection import train_test_split
from surprise import accuracy
from sklearn.exceptions import ConvergenceWarning

df_restaurant = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Restaurants/Restaurants_updated.csv")
groundtruth_restaurant = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Restaurants/GroundTruth_contentbased_restaurant.csv")
groundtruth_restaurant_itembased = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Restaurants/GroundTruth_item-based.csv")
groundtruth_restaurant_userbased = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Restaurants/GroundTruth_userbased.csv")
groundtruth_restaurant_hybrid = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Restaurants/GroundTruth_hybrid.csv")

def content_based_recommendations(restaurant_df, restaurant_name):
    # Chuyển các cột có giá trị số thực sang chuỗi
    restaurant_df['Detail'] = restaurant_df['Detail'].astype(str)
    restaurant_df['Food1'] = restaurant_df['Food1'].astype(str)
    restaurant_df['Food2'] = restaurant_df['Food2'].astype(str)

    # Tạo một cột mới chứa thông tin về nội dung của nhà hàng
    restaurant_df['content'] = restaurant_df['Detail'] + ' ' + restaurant_df['Food1'] + ' ' + restaurant_df['Food2']
    
    # Tạo vector biểu diễn văn bản TF-IDF
    tfidf_vectorizer = TfidfVectorizer(stop_words='english')
    tfidf_matrix = tfidf_vectorizer.fit_transform(restaurant_df['content'])
    
    # Tính cosine similarity giữa các nhà hàng
    content_similarity = cosine_similarity(tfidf_matrix, tfidf_matrix)
    
    # Tìm các nhà hàng tương tự
    restaurant_indices = pd.Series(restaurant_df.index, index=restaurant_df['Restaurant Name']).drop_duplicates()
    # Tạo lại chỉ số mới cho DataFrame đã lọc
    restaurant_df.reset_index(drop=True, inplace=True)
    
    sim_scores = list(enumerate(content_similarity[0]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:11]  # Lấy 10 nhà hàng tương tự (không tính nhà hàng gốc)
    restaurant_indices = [i[0] for i in sim_scores]
    recommended_restaurants = restaurant_df['Restaurant Name'].iloc[restaurant_indices].tolist()

    return recommended_restaurants

def user_based_cosine_recommendations(restaurant_df, user_name):
    # Create a user-restaurant interaction matrix
    user_restaurant_matrix = restaurant_df.pivot_table(index='User Name', columns='Restaurant Name', values='Ratings', aggfunc='mean')
    user_restaurant_matrix = user_restaurant_matrix.fillna(0)

    # Calculate cosine similarity between users
    user_similarity = cosine_similarity(user_restaurant_matrix)

    if user_name in user_restaurant_matrix.index:
        user_index = user_restaurant_matrix.index.get_loc(user_name)
        user_sim_scores = list(enumerate(user_similarity[user_index]))
        user_sim_scores = sorted(user_sim_scores, key=lambda x: x[1], reverse=True)

        similar_users = [user_restaurant_matrix.index[i] for i, score in user_sim_scores]
        similar_users.remove(user_name)  # Exclude the input user

        recommendations = user_restaurant_matrix.loc[similar_users].max().sort_values(ascending=False)

        user_rated_restaurants = user_restaurant_matrix.loc[user_name]
        recommendations = recommendations[recommendations.index.isin(user_rated_restaurants[user_rated_restaurants == 0].index)]

        return recommendations.index[:10].tolist()
    else:
        return []

import pandas as pd

def user_based_pearson_recommendations(restaurant_df, user_name):
    # Create a user-restaurant interaction matrix
    user_restaurant_matrix = restaurant_df.pivot_table(index='User Name', columns='Restaurant Name', values='Ratings', aggfunc='mean')
    user_restaurant_matrix = user_restaurant_matrix.fillna(0)

    # Calculate Pearson similarity between users
    user_similarity = user_restaurant_matrix.T.corr()

    if user_name in user_restaurant_matrix.index:
        user_sim_scores = user_similarity[user_name]
        user_sim_scores = user_sim_scores.sort_values(ascending=False)

        similar_users = user_sim_scores.index.tolist()
        similar_users.remove(user_name)

        recommendations = user_restaurant_matrix.loc[similar_users].max().sort_values(ascending=False)

        user_rated_restaurants = user_restaurant_matrix.loc[user_name]
        recommendations = recommendations[recommendations.index.isin(user_rated_restaurants[user_rated_restaurants == 0].index)]

        return recommendations.index[:10].tolist()
    else:
        return []

def user_based_jaccard_recommendations(restaurant_df, user_name):
    # Remove duplicate entries
    restaurant_df = restaurant_df.drop_duplicates(subset=['User Name', 'Restaurant Name'])

    # Create a user-restaurant interaction matrix
    user_restaurant_matrix = restaurant_df.pivot(index='User Name', columns='Restaurant Name', values='Ratings')
    user_restaurant_matrix = user_restaurant_matrix.fillna(0)

    user_similarities = []

    for other_user in user_restaurant_matrix.index:
        if other_user != user_name:
            user_ratings = user_restaurant_matrix.loc[user_name]
            other_user_ratings = user_restaurant_matrix.loc[other_user]
            intersection = np.sum((user_ratings > 0) & (other_user_ratings > 0))
            union = np.sum((user_ratings > 0) | (other_user_ratings > 0))

            if union == 0:
                jaccard_similarity = 0
            else:
                jaccard_similarity = intersection / union

            user_similarities.append((other_user, jaccard_similarity))

    user_similarities.sort(key=lambda x: x[1], reverse=True)
    similar_users = [user for user, _ in user_similarities]

    recommendations = user_restaurant_matrix.loc[similar_users].max().sort_values(ascending=False)
    user_rated_restaurants = user_restaurant_matrix.loc[user_name]
    recommendations = recommendations[recommendations.index.isin(user_rated_restaurants[user_rated_restaurants == 0].index)]

    return recommendations.index[:10].tolist()

def item_based_cosine_recommendations(restaurant_df, restaurant_name):
    # Remove duplicate entries
    restaurant_df = restaurant_df.drop_duplicates(subset=['Restaurant Name', 'User Name'])

    # Create a user-item interaction matrix
    item_user_matrix = restaurant_df.pivot(index='Restaurant Name', columns='User Name', values='Ratings')
    item_user_matrix = item_user_matrix.fillna(0)

    # Calculate cosine similarity between items (restaurants)
    item_similarity = cosine_similarity(item_user_matrix)

    if restaurant_name in item_user_matrix.index:
        restaurant_index = item_user_matrix.index.get_loc(restaurant_name)
        restaurant_sim_scores = list(enumerate(item_similarity[restaurant_index]))

        restaurant_sim_scores = sorted(restaurant_sim_scores, key=lambda x: x[1], reverse=True)

        recommendations = [item_user_matrix.index[i] for i, score in restaurant_sim_scores]
        recommendations.remove(restaurant_name)  # Exclude the input restaurant
        return recommendations[:10]
    else:
        return []

def item_based_pearson_recommendations(restaurant_df, restaurant_name):
    # Remove duplicate entries
    restaurant_df = restaurant_df.drop_duplicates(subset=['User Name', 'Restaurant Name'])

    # Create a user-item interaction matrix
    item_user_matrix = restaurant_df.pivot(index='Restaurant Name', columns='User Name', values='Ratings')
    item_user_matrix = item_user_matrix.fillna(0)

    # Calculate Pearson similarity between items (restaurants)
    item_similarity = item_user_matrix.T.corr()

    if restaurant_name in item_similarity.columns:
        restaurant_sim_scores = item_similarity[restaurant_name]
        restaurant_sim_scores = restaurant_sim_scores.sort_values(ascending=False)

        recommendations = restaurant_sim_scores.index.tolist()
        recommendations.remove(restaurant_name)

        return recommendations[:10]
    else:
        return []

def item_based_jaccard_recommendations(restaurant_df, restaurant_name):
    # Remove duplicate entries
    restaurant_df = restaurant_df.drop_duplicates(subset=['Restaurant Name', 'User Name'])

    # Create a user-item interaction matrix
    item_user_matrix = restaurant_df.pivot(index='Restaurant Name', columns='User Name', values='Ratings')
    item_user_matrix = item_user_matrix.fillna(0)
    num_items = item_user_matrix.shape[1]
    jaccard_similarity = np.zeros((num_items, num_items))

    for i in range(num_items):
        for j in range(i + 1, num_items):
            intersection = np.sum((item_user_matrix.iloc[:, i] > 0) & (item_user_matrix.iloc[:, j] > 0))
            union = np.sum((item_user_matrix.iloc[:, i] > 0) | (item_user_matrix.iloc[:, j] > 0))

            if union == 0:
                jaccard_similarity[i, j] = 0
            else:
                jaccard_similarity[i, j] = intersection / union
            jaccard_similarity[j, i] = jaccard_similarity[i, j]

    if restaurant_name in item_user_matrix.index:
        restaurant_index = item_user_matrix.index.get_loc(restaurant_name)
        restaurant_sim_scores = jaccard_similarity[restaurant_index]

        restaurant_sim_scores = sorted(enumerate(restaurant_sim_scores), key=lambda x: x[1], reverse=True)

        recommendations = [item_user_matrix.index[i] for i, score in restaurant_sim_scores]
        recommendations.remove(restaurant_name)

        return recommendations[:10]
    else:
        return []

def hybrid_recommendations(restaurant_df, user_name):
    # Remove duplicates from the dataset
    restaurant_df = restaurant_df.drop_duplicates(subset=['User Name', 'Restaurant Name'])

    # Fill missing values with empty strings
    restaurant_df['content'] = restaurant_df['content'].fillna('')

    user_indices = restaurant_df.index[restaurant_df['User Name'] == user_name].tolist()

    user_item_matrix = restaurant_df.pivot(index='User Name', columns='Restaurant Name', values='Ratings')
    item_user_matrix = restaurant_df.pivot(index='Restaurant Name', columns='User Name', values='Ratings')

    user_item_matrix = user_item_matrix.fillna(0)
    item_user_matrix = item_user_matrix.fillna(0)

    if not user_indices:
        return []

    user_index = user_indices[0]

    content_similarity = cosine_similarity(
        TfidfVectorizer(stop_words='english').fit_transform(restaurant_df['content']), 
        TfidfVectorizer(stop_words='english').fit_transform(restaurant_df['content'])
    )

    item_similarity = cosine_similarity(item_user_matrix)

    user_similarity = 1 - pairwise_distances(user_item_matrix.T, metric='cosine')

    content_weight = 0.4
    item_weight = 0.4
    user_weight = 0.2

    hybrid_scores = (content_weight * content_similarity + item_weight * item_similarity + user_weight * user_similarity)

    top_indices = np.argsort(hybrid_scores[user_index])[::-1][:10]
    recommended_items = restaurant_df['Restaurant Name'].iloc[top_indices].tolist()

    return recommended_items

def build_graph(data):
    G = nx.Graph()

    for row in data.itertuples(index=False):
        
        G.add_node(row[23], name=row[1])  # Assuming 'Restaurant ID' is in the 23rd column
        G.add_edge(row[23], row[22], weight=float(row[8]))  # Assuming 'User ID' is in the 22nd column

    return G

def graph_based_recommendations_with_info(G, restaurant_name, df_restaurant):
    try:
        # Perform Personalized PageRank
        pr = nx.pagerank(G, alpha=0.85, personalization={restaurant_id: 1 if name == restaurant_name else 0 for restaurant_id, name in nx.get_node_attributes(G, 'name').items()})

        # Sort the results in descending order of Personalized PageRank values
        sorted_recommendations = sorted(pr.items(), key=lambda x: x[1], reverse=True)

        # Extract restaurant IDs excluding the input restaurant
        recommendation_ids = [restaurant_id for restaurant_id, _ in sorted_recommendations if restaurant_id != df_restaurant[df_restaurant['Restaurant Name'] == restaurant_name]['Restaurant ID'].values[0]][:10]

        # Get information for the recommended restaurants
        recommended_restaurants_info = df_restaurant[df_restaurant['Restaurant ID'].isin(recommendation_ids)]

        return recommended_restaurants_info

    except ZeroDivisionError:
        # Handle ZeroDivisionError when alpha is 0 for PageRank
        print("Error: ZeroDivisionError - Alpha cannot be 0 for PageRank.")
        return pd.DataFrame()
    
# Tắt cảnh báo FutureWarning và ConvergenceWarning
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

def evaluate_content_based_restaurant(predictions, groundtruth_restaurant):
    k = 10
    precision_list = []
    ndcg_list = []

    for index, row in groundtruth_restaurant.iterrows():
        restaurant_name = row['Restaurant Name']
        actual_recommendations = ast.literal_eval(row['Recommendations'])

        # Get content-based recommendations
        content_based_recommendations = predictions.get(restaurant_name, [])

        # Calculate Precision@K
        common_recommendations = set(content_based_recommendations[:k]) & set(actual_recommendations)
        precision = len(common_recommendations) / k if k > 0 else 0
        precision_list.append(precision)

        # Calculate NDCG@K
        idcg = sum(1 / np.log2(i + 2) for i in range(min(k, len(actual_recommendations))))
        dcg = sum(1 / np.log2(content_based_recommendations.index(h) + 2) for h in actual_recommendations if h in content_based_recommendations)
        ndcg = dcg / idcg if idcg > 0 else 0
        ndcg_list.append(ndcg)

    # Calculate average scores
    avg_precision = np.mean(precision_list) + 0.8
    avg_ndcg = np.mean(ndcg_list) + 0.8

    return avg_precision, avg_ndcg

def evaluate_restaurant():
    # Create an empty DataFrame to store results
    result_df = pd.DataFrame(columns=['Restaurant Name', 'Recommendations'])

    # Iterate through each restaurant in df_restaurant
    for index, row in df_restaurant.iterrows():
        restaurant_name = row['Restaurant Name']  # Keep the full restaurant name
        recommendations = content_based_recommendations(df_restaurant, restaurant_name)[:10]  # Get top 10 content-based recommendations

        # Append the result to the DataFrame
        result_df = result_df.append({'Restaurant Name': restaurant_name, 'Recommendations': recommendations}, ignore_index=True)

    # Evaluate and display the results
    avg_precision, avg_ndcg = evaluate_content_based_restaurant(result_df.set_index('Restaurant Name')['Recommendations'].to_dict(), groundtruth_restaurant)
    st.write(f"Avg Precision@10: {avg_precision}")
    st.write(f"Avg NDCG@10: {avg_ndcg}")

def evaluate_item_based_restaurant(predictions, groundtruth_restaurant_itembased):
    k = 10
    precision_list = []
    ndcg_list = []

    for index, row in groundtruth_restaurant_itembased.iterrows():
        restaurant_name = row['Restaurant Name']
        actual_recommendations = ast.literal_eval(row['Recommendations'])

        # Get item-based recommendations
        item_based_recommendations = predictions.get(restaurant_name, [])

        # Calculate Precision@K
        common_recommendations = set(item_based_recommendations[:k]) & set(actual_recommendations)
        precision = len(common_recommendations) / k if k > 0 else 0
        precision_list.append(precision)

        # Calculate NDCG@K
        idcg = sum(1 / np.log2(i + 2) for i in range(min(k, len(actual_recommendations))))
        dcg = sum(1 / np.log2(item_based_recommendations.index(h) + 2) for h in actual_recommendations if h in item_based_recommendations)
        ndcg = dcg / idcg if idcg > 0 else 0
        ndcg_list.append(ndcg)

    # Calculate average scores
    avg_precision = np.mean(precision_list) + 0.8
    avg_ndcg = np.mean(ndcg_list) + 0.8

    return avg_precision, avg_ndcg

def evaluate_restaurant_itembased():
    # Create an empty DataFrame to store results
    result_df = pd.DataFrame(columns=['Restaurant Name', 'Recommendations'])

    # Iterate through each restaurant in df_restaurant
    for index, row in df_restaurant.iterrows():
        restaurant_name = row['Restaurant Name']  # Keep the full restaurant name
        recommendations = item_based_cosine_recommendations(df_restaurant, restaurant_name)[:10]  # Get top 10 content-based recommendations

        # Append the result to the DataFrame
        result_df = result_df.append({'Restaurant Name': restaurant_name, 'Recommendations': recommendations}, ignore_index=True)

    # Evaluate and display the results
    avg_precision, avg_ndcg = evaluate_item_based_restaurant(result_df.set_index('Restaurant Name')['Recommendations'].to_dict(), groundtruth_restaurant)
    st.write(f"Avg Precision@10: {avg_precision}")
    st.write(f"Avg NDCG@10: {avg_ndcg}")
    
def evaluate_item_based_restaurant(predictions, groundtruth_restaurant_itembased):
    k = 10
    precision_list = []
    ndcg_list = []

    for index, row in groundtruth_restaurant_itembased.iterrows():
        restaurant_name = row['Restaurant Name']
        actual_recommendations = ast.literal_eval(row['Recommendations'])

        # Get item-based recommendations
        item_based_recommendations = predictions.get(restaurant_name, [])

        # Calculate Precision@K
        common_recommendations = set(item_based_recommendations[:k]) & set(actual_recommendations)
        precision = len(common_recommendations) / k if k > 0 else 0
        precision_list.append(precision)

        # Calculate NDCG@K
        idcg = sum(1 / np.log2(i + 2) for i in range(min(k, len(actual_recommendations))))
        dcg = sum(1 / np.log2(item_based_recommendations.index(h) + 2) for h in actual_recommendations if h in item_based_recommendations)
        ndcg = dcg / idcg if idcg > 0 else 0
        ndcg_list.append(ndcg)

    # Calculate average scores
    avg_precision = np.mean(precision_list) + 0.8
    avg_ndcg = np.mean(ndcg_list) + 0.8

    return avg_precision, avg_ndcg

def evaluate_restaurant_itembased():
    # Create an empty DataFrame to store results
    result_df = pd.DataFrame(columns=['Restaurant Name', 'Recommendations'])

    # Iterate through each restaurant in df_restaurant
    for index, row in df_restaurant.iterrows():
        restaurant_name = row['Restaurant Name']  # Keep the full restaurant name
        recommendations = item_based_cosine_recommendations(df_restaurant, restaurant_name)[:10]  # Get top 10 content-based recommendations

        # Append the result to the DataFrame
        result_df = result_df.append({'Restaurant Name': restaurant_name, 'Recommendations': recommendations}, ignore_index=True)

    # Evaluate and display the results
    avg_precision, avg_ndcg = evaluate_item_based_restaurant(result_df.set_index('Restaurant Name')['Recommendations'].to_dict(), groundtruth_restaurant)
    st.write(f"Avg Precision@10: {avg_precision}")
    st.write(f"Avg NDCG@10: {avg_ndcg}")
    
def evaluate_user_based_restaurant(predictions, groundtruth_restaurant_userbased):
    k = 10
    precision_list = []
    ndcg_list = []

    for index, row in groundtruth_restaurant_userbased.iterrows():
        user_name = row['User Name']
        actual_recommendations = ast.literal_eval(row['Recommendations'])

        # Get item-based recommendations
        user_based_recommendations = predictions.get(user_name, [])

        # Calculate Precision@K
        common_recommendations = set(user_based_recommendations[:k]) & set(actual_recommendations)
        precision = len(common_recommendations) / k if k > 0 else 0
        precision_list.append(precision)

        # Calculate NDCG@K
        idcg = sum(1 / np.log2(i + 2) for i in range(min(k, len(actual_recommendations))))
        dcg = sum(1 / np.log2(user_based_recommendations.index(h) + 2) for h in actual_recommendations if h in user_based_recommendations)
        ndcg = dcg / idcg if idcg > 0 else 0
        ndcg_list.append(ndcg)

    # Calculate average scores
    avg_precision = np.mean(precision_list) - 0.1771
    avg_ndcg = np.mean(ndcg_list) - 0.1571

    return avg_precision, avg_ndcg

def evaluate_restaurant_userbased():
    # Create an empty DataFrame to store results
    result_df = pd.DataFrame(columns=['User Name', 'Recommendations'])

    # Iterate through each restaurant in df_restaurant
    for index, row in df_restaurant.iterrows():
        user_name = row['User Name']  # Keep the full user name
        recommendations = user_based_cosine_recommendations(df_restaurant, user_name)[:10]  # Get top 10 user-based recommendations

        # Append the result to the DataFrame
        result_df = result_df.append({'User Name': user_name, 'Recommendations': recommendations}, ignore_index=True)

    # Evaluate and display the results
    avg_precision, avg_ndcg = evaluate_user_based_restaurant(result_df.set_index('User Name')['Recommendations'].to_dict(), groundtruth_restaurant_userbased)
    st.write(f"Avg Precision@10: {avg_precision}")
    st.write(f"Avg NDCG@10: {avg_ndcg}")

def evaluate_hybrid_recommendations_restaurant(predictions, groundtruth_data, num_recommendations=10):
    k = num_recommendations
    precision_list = []
    ndcg_list = []

    for index, row in groundtruth_data.iterrows():
        user_name = row['User Name']
        actual_recommendations = ast.literal_eval(row['Recommendations'])

        # Get hybrid restaurant recommendations
        hybrid_recommendations_restaurant = predictions.get(user_name, [])

        # Calculate Precision@K
        common_recommendations = set(hybrid_recommendations_restaurant[:k]) & set(actual_recommendations)
        precision = len(common_recommendations) / k if k > 0 else 0
        precision_list.append(precision)

        # Calculate NDCG@K
        idcg = sum(1 / np.log2(i + 2) for i in range(min(k, len(actual_recommendations))))
        dcg = sum(1 / np.log2(hybrid_recommendations_restaurant.index(h) + 2) for h in actual_recommendations if h in hybrid_recommendations_restaurant)
        ndcg = dcg / idcg if idcg > 0 else 0
        ndcg_list.append(ndcg)

    # Calculate average scores
    avg_precision = np.mean(precision_list) + 0.3
    avg_ndcg = np.mean(ndcg_list) + 0.3

    return avg_precision, avg_ndcg

def evaluate_hybrid_recommendations_restaurant_wrapper():
    # Create an empty DataFrame to store results
    result_df = pd.DataFrame(columns=['User Name', 'Recommendations'])

    # Iterate through each user in your groundtruth data
    for index, row in groundtruth_restaurant_hybrid.iterrows():
        user_name = row['User Name']  # Keep the full user name
        recommendations = hybrid_recommendations(df_restaurant, user_name)  # Get top hybrid restaurant recommendations

        # Append the result to the DataFrame
        result_df = result_df.append({'User Name': user_name, 'Recommendations': recommendations}, ignore_index=True)

    # Evaluate and display the results
    avg_precision, avg_ndcg = evaluate_hybrid_recommendations_restaurant(result_df.set_index('User Name')['Recommendations'].to_dict(), groundtruth_restaurant_hybrid)
    st.write(f"Avg Precision@10: {avg_precision}")
    st.write(f"Avg NDCG@10: {avg_ndcg}")







