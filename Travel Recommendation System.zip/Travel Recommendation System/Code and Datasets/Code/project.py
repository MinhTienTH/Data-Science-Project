import streamlit as st
import ast

# Import your location-specific modules and dataframes here
import ConDao
import DaLat
import DaNang
import HaNoi
import HoChiMinh
import HoiAn
import Hue
import NhaTrang
import NinhBinh
import PhanThiet
import PhuQuoc
import SaPa
import VungTau

import Restaurant
from Restaurant import *

import MachineLeaning_Predict_Rating_Hotel
from MachineLeaning_Predict_Rating_Hotel import *

import MachineLeaning_Predict_Rating_Restaurant
from MachineLeaning_Predict_Rating_Restaurant import *

import MachineLeaning_Predict_Rating_Attraction
from MachineLeaning_Predict_Rating_Attraction import *

import NeuralNetwork_Predict_Rating_Hotel
from NeuralNetwork_Predict_Rating_Hotel import *

import NeuralNetwork_Predict_Rating_Restaurant
from NeuralNetwork_Predict_Rating_Restaurant import *

import NeuralNetwork_Predict_Rating_Attraction
from NeuralNetwork_Predict_Rating_Attraction import *

## import graph_neural_network_hotel
## from graph_neural_network_hotel import *

import DaNang_At
import HaNoi_At
import HoiAn_At
import Hue_At
import NhaTrang_At
import HoChiMinh_At
import warnings
from sklearn.exceptions import ConvergenceWarning

from DaNang_At import *
from ConDao import *
from DaLat import *

combined_df_attraction = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Attractions/Dataset_Predict_Rating_attraction.csv")

# Chuyển giá trị từ 1.0 thành 1 trong cột 'User ID'
combined_df_attraction['User ID'] = combined_df_attraction['User ID'].astype(int)

# Sắp xếp DataFrame dựa trên cột 'User ID' tăng dần
combined_df_attraction.sort_values(by='User ID', inplace=True)
    
# Create a dictionary to map location names to data and functions
locations = {
    "Côn Đảo": (ConDao, ConDao.df_hotel_ConDao),
    "Đà Lạt": (DaLat, DaLat.df_hotel_DaLat),
    "Đà Nẵng": (DaNang, DaNang.df_hotel_DaNang),
    "Hà Nội": (HaNoi, HaNoi.df_hotel_HaNoi),
    "Hồ Chí Minh": (HoChiMinh, HoChiMinh.df_hotel_HoChiMinh),
    "Hội An": (HoiAn, HoiAn.df_hotel_HoiAn),
    "Huế": (Hue, Hue.df_hotel_Hue),
    "Nha Trang": (NhaTrang, NhaTrang.df_hotel_NhaTrang),
    "Ninh Bình": (NinhBinh, NinhBinh.df_hotel_NinhBinh),
    "Phan Thiết": (PhanThiet, PhanThiet.df_hotel_PhanThiet),
    "Phú Quốc": (PhuQuoc, PhuQuoc.df_hotel_PhuQuoc),
    "Sa Pa": (SaPa, SaPa.df_hotel_SaPa),
    "Vũng Tàu": (VungTau, VungTau.df_hotel_VungTau)
}

locations_attraction = {
    "Đà Nẵng": (DaNang_At, DaNang_At.df_attraction_DaNang_att),
    "Hà Nội": (HaNoi_At, HaNoi_At.df_attraction_HaNoi_att),
    "Hồ Chí Minh": (HoChiMinh_At, HoChiMinh_At.df_attraction_HoChiMinh_att),
    "Hội An": (HoiAn_At, HoiAn_At.df_attraction_HoiAn_att),
    "Huế": (Hue_At, Hue_At.df_attraction_Hue_att),
    "Nha Trang": (NhaTrang_At, NhaTrang_At.df_attraction_NhaTrang_att)
}

# Create a dictionary to map location names to data and functions
locations_groundtruth = {
    "Côn Đảo": (ConDao, ConDao.groundtruth_condao),
    "Đà Lạt": (DaLat, DaLat.groundtruth_dalat),
    "Đà Nẵng": (DaNang, DaNang.groundtruth_danang),
    "Hà Nội": (HaNoi, HaNoi.groundtruth_hanoi),
    "Hồ Chí Minh": (HoChiMinh, HoChiMinh.groundtruth_hochiminh),
    "Hội An": (HoiAn, HoiAn.groundtruth_hoian),
    "Huế": (Hue, Hue.groundtruth_hue),
    "Nha Trang": (NhaTrang, NhaTrang.groundtruth_nhatrang),
    "Ninh Bình": (NinhBinh, NinhBinh.groundtruth_ninhbinh),
    "Phan Thiết": (PhanThiet, PhanThiet.groundtruth_phanthiet),
    "Phú Quốc": (PhuQuoc, PhuQuoc.groundtruth_phuquoc),
    "Sa Pa": (SaPa, SaPa.groundtruth_sapa),
    "Vũng Tàu": (VungTau, VungTau.groundtruth_vungtau)
}

st.title("Hệ thống Recommend")

if 'selected_place' not in st.session_state:
    st.session_state.selected_place = None

selected_place = st.session_state.selected_place

page = st.sidebar.radio("Chọn trang", ["Trang chủ", "Recommend", "Predicted Rating"])

if page == "Trang chủ":
    st.header("Trang chủ")

    category = st.sidebar.selectbox("Chọn danh mục", ["--- Trống ---", "Hotel", "Restaurant", "Attraction"])

    if category == "Hotel":
        st.write("Danh sách địa điểm:")
        place_list = list(locations.keys())
        place_list.insert(0, "--- Trống ---")
        selected_place = st.selectbox("Chọn địa điểm", place_list)
        if selected_place != "--- Trống ---":
            st.session_state.selected_place = selected_place  # Lưu selected_place vào session_state
            price_range = st.slider("Khoảng giá", 0, 1500000, (0, 1500000))

            if selected_place and selected_place != "--- Trống ---":
                services = st.multiselect("Chọn dịch vụ", [
                    "Airport shuttle", "Non-smoking rooms", "Room service", "Free parking", "Restaurant",
                    "Free WiFi", "Family rooms", "Good breakfast", "Bar", "Tea/coffee maker in all rooms",
                    "Beachfront", "Private beach area", "Spa and wellness centre", "Lift", "Terrace", "Lockers", "Garden", "Balcony", "BBQ facilities", "Bicycle rental", "Mini golf",
                    "Facilities for disabled guests", "Outdoor swimming pool"])

                # Limit the number of selected services to a maximum of 3
                if len(services) > 3:
                    st.warning("Bạn chỉ được chọn tối đa 3 dịch vụ.")
                    services = services[:3]

                can_search = True

                st.write(f"Dịch vụ đã chọn: {', '.join(services)}")
                st.write(f"Danh mục: {category}")

                if can_search:
                    if st.button("Tìm kiếm"):
                        st.write("Đang thực hiện tìm kiếm...")
                        location_module, location_data = locations[selected_place]

                        filtered_data = location_data[(location_data['Base Price'] >= price_range[0]) & (location_data['Base Price'] <= price_range[1])]

                        # Create a list of valid services (services that exist in the dataset)
                        valid_services = [service for service in services if service in location_data.columns]

                        for service in valid_services:
                            filtered_data = filtered_data[filtered_data[service] == 1]

                        if len(filtered_data) > 0:
                            st.write("Danh sách các khách sạn phù hợp:")
                            st.dataframe(filtered_data)
                            st.markdown("[**Tiến hành Recommend**](#recommend)")
                        else:
                            st.write("Không có khách sạn phù hợp với tiêu chí đã chọn.")
            elif selected_place == "--- Trống ---":
                st.write("Vui lòng chọn địa điểm để tiến hành tìm kiếm.")
        else:
            st.write("Chọn một địa điểm để tiến hành tìm kiếm.")

    elif category == "Restaurant":
        st.write("Danh sách địa điểm:")
        restaurant_locations = ["--- Trống ---", "Hồ Chí Minh", "Hà Nội", "Hội An", "Huế", "Nha Trang", "Phú Quốc", "Đà Nẵng", "Đà Lạt", "Ninh Bình", "Phan Thiết", "Vũng Tàu"]
        selected_place = st.selectbox("Chọn địa điểm", restaurant_locations)
        if selected_place != "--- Trống ---":
            st.session_state.selected_place = selected_place

            can_search = True
            
            # Split the selected services and food items
            selected_services = st.multiselect("Dịch vụ của nhà hàng:", [
                "Accepts Credit Cards", "Serves Alcohol", "Reservations", "Private Dining", "Family style", "Highchairs Available", "Live Music",
                "Seating", "Cash Only", "Table Service", "Free Wifi", "Free off-street parking", "Accepts American Express", "Accepts Visa",
                "Accepts Mastercard", "Accepts Discover", "Gift Cards Available", "Outdoor Seating",
                "Full Bar", "Television", "Waterfront", "Wheelchair Accessible", "Halal", "Television"
            ])
            if len(selected_services) > 3:
                st.warning("Bạn chỉ được chọn tối đa 3 dịch vụ.")
                can_search = False
                   
            selected_food = st.multiselect("Loại đồ ăn:", [
                "Soups", "Seafood", "Pakistani", "Street Food", "Fast Food", "Southwestern", "Greek", "Deli", "Steakhouse", "Wine and Beer", "Turkish",
                "Indian", "Mexican", "Southern-Italian", "Jazz Bar", "Irish", "Cafe", "Spanish", "Central Asian", "Central European", "Canadian",
                "Live Music", "Vegetarian Friendly", "Dining bars", "Late Night", "Armenian", "Chinese", "Australian", "Arabic", "International",
                "Lunch", "Drinks", "Mediterranean", "Fruit parlours", "Azerbaijani", "British", "Barbecue", "American", "Neapolitan", "Healthy",
                "Lazio", "Sushi", "Brunch", "Swiss", "Central-Italian", "Diner", "Sports bars", "Latin", "Kyushu cuisine", "Pub", "Digital Payments",
                "Japanese", "Afghan", "French", "Dog Friendly", "Romana", "Wine Bar", "Middle Eastern", "Japanese Fusion", "Takeout", "Delivery",
                "Italian", "Street Parking", "Asian", "European", "Bar", "Buffet", "Vietnamese", "Grill", "Breakfast", "Non-smoking restaurants",
                "Egyptian", "Pizza", "German", "Brew Pub", "Contemporary", "Vegan Options", "Thai", "Gluten Free Options", "Sicilian", "Fusion",
                "Gastropub", "Lebanese"
            ])
            if len(selected_food) > 3:
                st.warning("Bạn chỉ được chọn tối đa 3 loại đồ ăn.")
                can_search = False

            if can_search:
                if st.button("Tìm kiếm"):
                    st.write("Đang thực hiện tìm kiếm...")
                    filtered_data = df_restaurant[df_restaurant["Address"] == selected_place]

                    if len(selected_services) > 0 or len(selected_food) > 0:
                        filtered_data = filtered_data[
                            filtered_data["Food1"].str.contains("|".join(selected_services), case=False) |
                            filtered_data["Food2"].str.contains("|".join(selected_services), case=False) |
                            filtered_data["Food1"].str.contains("|".join(selected_food), case=False) |
                            filtered_data["Food2"].str.contains("|".join(selected_food), case=False)
                        ]
                        
                    filtered_data = filtered_data.reset_index(drop=True)
                    
                    if len(filtered_data) > 0:
                        st.write("Danh sách nhà hàng phù hợp:")
                        st.dataframe(filtered_data.iloc[:, 1:])
                    else:
                        st.write("Không có nhà hàng phù hợp với tiêu chí đã chọn.")
            else:
                st.write("Vui lòng chọn ít nhất một dịch vụ và một loại đồ ăn để tiến hành tìm kiếm.")
        elif selected_place == "--- Trống ---":
            st.write("Vui lòng chọn địa điểm để tiến hành tìm kiếm.")
        else:
            st.write("Chọn một địa điểm để tiến hành tìm kiếm.")
    else:
        st.write("Chọn danh mục để tiến hành tìm kiếm.")

    if category == "Attraction":
        st.write("Danh sách địa điểm:")
        place_list = list(locations_attraction.keys())
        place_list.insert(0, "--- Trống ---")
        selected_place = st.selectbox("Chọn địa điểm", place_list)
        if selected_place != "--- Trống ---":
            st.session_state.selected_place = selected_place  # Lưu selected_place vào session_state
            price_range = st.slider("Khoảng giá", 0, 1500000, (0, 1500000))

            if selected_place and selected_place != "--- Trống ---":
                services = st.multiselect("Chọn dịch vụ", [
                    "Du thuyền 45 phút", "Nhạc sống", "Nước đóng chai", "Trái cây", "Bảo hiểm", "Máy hát karaoke", "Góc selfie",    
                    "Buffet trưa tại nhà hàng", "Đi cáp treo", "Đón và trả khách", "Dịch vụ hướng dẫn", "Phương tiện đi lại khứ hồi", "Vé vào các điểm tham quan",
                    "Lớp học nấu ăn", "Đầu bếp nói", "Dịch vụ hướng dẫn bằng tiếng anh", "Cà phê", "Thuê xe đạp"])

                # Limit the number of selected services to a maximum of 3
                if len(services) > 3:
                    st.warning("Bạn chỉ được chọn tối đa 3 dịch vụ.")
                    services = services[:3]

                can_search = True

                st.write(f"Dịch vụ đã chọn: {', '.join(services)}")
                st.write(f"Danh mục: {category}")

                if can_search:
                    if st.button("Tìm kiếm"):
                        st.write("Đang thực hiện tìm kiếm...")
                        location_module, location_data = locations_attraction[selected_place]

                        filtered_data = location_data[(location_data['Price'] >= price_range[0]) & (location_data['Price'] <= price_range[1])]

                        # Create a list of valid services (services that exist in the dataset)
                        valid_services = [service for service in services if service in location_data.columns]

                        for service in valid_services:
                            filtered_data = filtered_data[filtered_data[service] == 1]

                        if len(filtered_data) > 0:
                            st.write("Danh sách các nhà hàng phù hợp:")
                            filtered_data = filtered_data.drop(["Service1", "Service2"], axis=1)
                            st.dataframe(filtered_data)
                            st.markdown("[**Tiến hành Recommend**](#recommend)")
                        else:
                            st.write("Không có nhà hàng nào phù hợp với tiêu chí đã chọn.")
            elif selected_place == "--- Trống ---":
                st.write("Vui lòng chọn địa điểm để tiến hành tìm kiếm.")
        else:
            st.write("Chọn một địa điểm để tiến hành tìm kiếm.")

elif page == "Recommend":
    
    category = st.sidebar.selectbox("Chọn danh mục", ["--- Trống ---", "Hotel", "Restaurant", "Attraction"])
    
    if category == "Hotel":
        st.header("Trang Recommend")

        recommend_method = st.sidebar.selectbox("Chọn phương pháp recommend", ["--- Trống ---", "Content-based", "Item-based", "User-based", "Hybrid", "Graph-based"])
        recommend_pressed = False
        recommendations_placeholder = st.empty()

        if recommend_method != "--- Trống ---":
            if recommend_method in ["Content-based", "Hybrid", "Graph-based"]:
                similarity_measure = None
            else:
                similarity_measure = st.sidebar.selectbox("Chọn độ đo tương tự", ["Cosine", "Pearson", "Jaccard"])
            
            if recommend_method in ["Content-based", "Item-based", "Graph-based"]:
                hotel_name = st.text_input("Nhập tên khách sạn để recommend:")
            if recommend_method in ["User-based", "Hybrid"]:
                user_name = st.text_input("Nhập tên người dùng để recommend:")
            
            if st.button("Recommend"):
                recommend_pressed = True

            if recommend_pressed:
                if selected_place:
                    location_module, location_data = locations[selected_place]
                    location_module_1, location_groundtruth = locations_groundtruth[selected_place]
                    
                    if recommend_method == "Content-based":
                        recommendations = location_module.content_based_recommendations(hotel_name)
                    elif recommend_method == "Item-based":
                        if similarity_measure == "Cosine":
                            recommendations = location_module.item_based_cosine_recommendations(hotel_name)
                        elif similarity_measure == "Pearson":
                            recommendations = location_module.item_based_pearson_recommendations(hotel_name)
                        elif similarity_measure == "Jaccard":
                            recommendations = location_module.item_based_jaccard_recommendations(hotel_name)
                    elif recommend_method == "User-based":
                        if similarity_measure == "Cosine":
                            recommendations = location_module.user_based_cosine_recommendations(user_name)
                        elif similarity_measure == "Pearson":
                            recommendations = location_module.user_based_pearson_recommendations(user_name)
                        elif similarity_measure == "Jaccard":
                            recommendations = location_module.user_based_jaccard_recommendations(user_name)
                    elif recommend_method == "Hybrid":
                        recommendations = location_module.hybrid_recommendations(user_name)
                    elif recommend_method == "Graph-based":
                        # Gọi hàm build_graph từ graph.py
                        your_graph = location_module.build_graph(location_data)
                        #your_graph = build_graph(location_data)
                        # Gọi hàm graph_based_recommendations từ graph.py
                        recommendations = location_module.graph_based_recommendations_with_info(your_graph, hotel_name, location_data)
                    recommendations_placeholder.text("Danh sách khách sạn được recommend:")
                    
                    if recommend_method != "Graph-based":
                        recommendations_df = location_data[location_data['Hotel Name'].isin(recommendations)]
                        st.dataframe(recommendations_df)
                    else:
                        st.dataframe(recommendations)
                    if recommend_method == "Content-based":
                        st.write("Thang đo đánh giá Top 10 hotels cho giải thuật Content-based:")
                        location_module_1.evaluate_hotel()
                    elif recommend_method == "Item-based":
                        st.write("Thang đo đánh giá Top 10 hotels cho giải thuật Item-based:")
                        location_module_1.evaluate_item_based_hotel()
                    elif recommend_method == "User-based":
                        st.write("Thang đo đánh giá Top 10 hotels cho giải thuật User-based:")
                        location_module_1.evaluate_user_based_hotel()
                    elif recommend_method == "Hybrid":
                        st.write("Thang đo đánh giá Top 10 hotels cho giải thuật Hybrid:")
                        location_module_1.evaluate_hybrid_recommendations_wrapper()
                else:
                    st.write("Vui lòng chọn địa điểm để tiến hành recommend.")
                    
    if category == "Restaurant":
        st.header("Trang Recommend")
        filtered_restaurants = df_restaurant.loc[df_restaurant['Address'] == selected_place]
        recommend_method = st.sidebar.selectbox("Chọn phương pháp recommend", ["--- Trống ---", "Content-based", "Item-based", "User-based", "Hybrid", "Graph-based"])
        recommend_pressed = False
        recommendations_placeholder = st.empty()

        if recommend_method != "--- Trống ---":
            if recommend_method in ["Content-based", "Hybrid", "Graph-based"]:
                similarity_measure = None
            else:
                similarity_measure = st.sidebar.selectbox("Chọn độ đo tương tự", ["Cosine", "Pearson", "Jaccard"])
            
            if recommend_method in ["Content-based", "Item-based", "Graph-based"]:
                restaurant_name = st.text_input("Nhập tên nhà hàng để recommend:")
            if recommend_method in ["User-based", "Hybrid"]:
                user_name = st.text_input("Nhập tên người dùng để recommend:")
                
            if st.button("Recommend"):
                recommend_pressed = True

            if recommend_pressed:
                if selected_place:
                    location_module, location_data = locations[selected_place]

                    if recommend_method == "Content-based":
                        recommendations = Restaurant.content_based_recommendations(filtered_restaurants, restaurant_name)
                    elif recommend_method == "Item-based":
                        if similarity_measure == "Cosine":
                            recommendations = Restaurant.item_based_cosine_recommendations(filtered_restaurants, restaurant_name)
                        elif similarity_measure == "Pearson":
                            recommendations = Restaurant.item_based_pearson_recommendations(filtered_restaurants, restaurant_name)
                        elif similarity_measure == "Jaccard":
                            recommendations = Restaurant.item_based_jaccard_recommendations(filtered_restaurants, restaurant_name)
                    elif recommend_method == "User-based":
                        if similarity_measure == "Cosine":
                            recommendations = Restaurant.user_based_cosine_recommendations(filtered_restaurants, user_name)
                        elif similarity_measure == "Pearson":
                            recommendations = Restaurant.user_based_pearson_recommendations(filtered_restaurants, user_name)
                        elif similarity_measure == "Jaccard":
                            recommendations = Restaurant.user_based_jaccard_recommendations(filtered_restaurants, user_name)
                    elif recommend_method == "Hybrid":
                        recommendations = Restaurant.hybrid_recommendations(filtered_restaurants, user_name)
                    elif recommend_method == "Graph-based":
                        # Gọi hàm build_graph từ graph.py
                        your_graph = Restaurant.build_graph(filtered_restaurants)
                        #your_graph = build_graph(location_data)
                        # Gọi hàm graph_based_recommendations từ graph.py
                        recommendations = Restaurant.graph_based_recommendations_with_info(your_graph, restaurant_name, filtered_restaurants)
                    recommendations_placeholder.text("Danh sách nhà hàng được recommend:")
                    
                    if recommend_method != "Graph-based":
                        recommendations_df = filtered_restaurants[filtered_restaurants['Restaurant Name'].isin(recommendations)]
                        st.dataframe(recommendations_df)
                    else:
                        recommendations = recommendations.drop(columns=['Unnamed: 0'])
                        st.dataframe(recommendations)
                        
                    if recommend_method == "Content-based":    
                        st.write("Thang đo đánh giá Top 10 restaurants cho giải thuật Content-based:")
                        Restaurant.evaluate_restaurant()
                    elif recommend_method == "Item-based":
                        st.write("Thang đo đánh giá Top 10 restaurants cho giải thuật Item-based:")
                        Restaurant.evaluate_restaurant_itembased()
                    elif recommend_method == "User-based":
                        st.write("Thang đo đánh giá Top 10 restaurants cho giải thuật User-based:")
                        Restaurant.evaluate_restaurant_userbased()    
                    elif recommend_method == "Hybrid":
                        st.write("Thang đo đánh giá Top 10 restaurants cho giải thuật Hybrid:")
                        Restaurant.evaluate_hybrid_recommendations_restaurant_wrapper() 
                else:
                    st.write("Vui lòng chọn địa điểm để tiến hành recommend.")

    if category == "Attraction":
        st.header("Trang Recommend")

        recommend_method = st.sidebar.selectbox("Chọn phương pháp recommend", ["--- Trống ---", "Content-based", "Item-based", "User-based", "Hybrid", "Graph-based"])
        recommend_pressed = False
        recommendations_placeholder = st.empty()

        if recommend_method != "--- Trống ---":
            if recommend_method in ["Content-based", "Hybrid", "Graph-based"]:
                similarity_measure = None
            else:
                similarity_measure = st.sidebar.selectbox("Chọn độ đo tương tự", ["Cosine", "Pearson", "Jaccard"])
            
            if recommend_method in ["Content-based", "Item-based", "Graph-based"]:
                attraction_name = st.text_input("Nhập tên điểm tham quan để recommend:")
                attraction_name = str(attraction_name)
            if recommend_method in ["User-based", "Hybrid"]:
                user_name = st.text_input("Nhập tên người dùng để recommend:")
                
            if st.button("Recommend"):
                recommend_pressed = True

            if recommend_pressed:
                if selected_place:
                    location_module, location_data = locations_attraction[selected_place]

                    if recommend_method == "Content-based":
                        recommendations = location_module.content_based_recommendations(attraction_name)
                    elif recommend_method == "Item-based":
                        if similarity_measure == "Cosine":
                            recommendations = location_module.item_based_cosine_recommendations(attraction_name)
                        elif similarity_measure == "Pearson":
                            recommendations = location_module.item_based_pearson_recommendations(attraction_name)
                        elif similarity_measure == "Jaccard":
                            recommendations = location_module.item_based_jaccard_recommendations(attraction_name)
                    elif recommend_method == "User-based":
                        if similarity_measure == "Cosine":
                            recommendations = location_module.user_based_cosine_recommendations(user_name)
                        elif similarity_measure == "Pearson":
                            recommendations = location_module.user_based_pearson_recommendations(user_name)
                        elif similarity_measure == "Jaccard":
                            recommendations = location_module.user_based_jaccard_recommendations(user_name)
                    elif recommend_method == "Hybrid":
                        recommendations = location_module.hybrid_recommendations(user_name)
                    elif recommend_method == "Graph-based":
                        # Gọi hàm build_graph từ graph.py
                        your_graph = location_module.build_graph(location_data)
                        #your_graph = build_graph(location_data)
                        # Gọi hàm graph_based_recommendations từ graph.py
                        recommendations = location_module.graph_based_recommendations_with_info(your_graph, attraction_name, location_data)                    
                    recommendations_placeholder.text("Danh sách nhà hàng được recommend:")
                    
                    if recommend_method != "Graph-based":
                        recommendations_df = location_data[location_data['Attraction Name'].isin(recommendations)]
                        st.dataframe(recommendations_df)
                    else:
                        #recommendations = recommendations.drop(columns=['Unnamed: 0'])
                        st.dataframe(recommendations)
                    if recommend_method == "Content-based":    
                        st.write("Thang đo đánh giá Top 10 attractions cho giải thuật Content-based:")
                        location_module.evaluate_attraction()
                    elif recommend_method == "Item-based":    
                        st.write("Thang đo đánh giá Top 10 attractions cho giải thuật Item-based:")
                        location_module.evaluate_attraction_itembased()
                    elif recommend_method == "User-based":    
                        st.write("Thang đo đánh giá Top 10 attractions cho giải thuật User-based:")
                        location_module.evaluate_attraction_userbased()
                    elif recommend_method == "Hybrid":
                        st.write("Thang đo đánh giá Top 10 attractions cho giải thuật Hybrid:")
                        location_module.evaluate_hybrid_recommendations_attraction() 
                else:
                    st.write("Vui lòng chọn địa điểm để tiến hành recommend.")
elif page == "Predicted Rating":
    st.header("Predict Rating")

    # Select the prediction model
    prediction_model = st.sidebar.selectbox("Chọn Model Dự Đoán", ["Linear Regression", "Random Forest", "Neural Network"])

    kind_predict = st.sidebar.selectbox("Chọn Danh Mục", ["Hotel", "Restaurant", "Attraction"])
    
    # Select the user for prediction
    if kind_predict == "Restaurant":
        selected_user_restaurant = st.selectbox("Select User", predict_rating_restaurant_df['User ID'].unique())
        user_features_restaurant_lr = predict_rating_restaurant_df[predict_rating_restaurant_df['User ID'] == selected_user_restaurant][['User ID', 'Restaurant ID', 'Food', 'Service', 'Value for money', 'Atmosphere']]
    
    if kind_predict == "Hotel":
        # Get user features based on the selected user
        selected_user_hotel = st.selectbox("Select User", predict_rating_hotel_df['User ID'].unique())
        user_features_hotel_lr = predict_rating_hotel_df[predict_rating_hotel_df['User ID'] == selected_user_hotel][['User ID', 'Hotel ID', 'Satisfaction', 'Staff', 'Facilities', 'Cleanliness', 'Comfort', 'Value for money', 'Location', 'Free Wifi']]

    if kind_predict == "Attraction":
        # Get user features based on the selected user
        selected_user_attraction = st.selectbox("Select User", predict_rating_attraction_df['User ID'].unique())
        user_features_attraction_lr = predict_rating_attraction_df[predict_rating_attraction_df['User ID'] == selected_user_attraction][['Attraction ID', 'User ID', 'Du thuyền 45 phút', 'Nhạc sống', 'Nước đóng chai', 'Trái cây', 'Bảo hiểm', 'Máy hát karaoke', 'Góc selfie', 'Buffet trưa tại nhà hàng', 'Đi cáp treo', 'Đón và trả khách', 'Dịch vụ hướng dẫn', 'Phương tiện đi lại khứ hồi', 'Vé vào các điểm tham quan', 'Lớp học nấu ăn', 'Đầu bếp nói', 'Dịch vụ hướng dẫn bằng tiếng anh', 'Cà phê', 'Thuê xe đạp']]

    # Button to perform prediction
    if st.button("Predicted Rating"):
        if kind_predict == "Hotel":
            if prediction_model == "Linear Regression":
                model_lr, X_test_lr, y_test_lr = MachineLeaning_Predict_Rating_Hotel.train_linear_regression_model_hotel()
                predicted_rating_lr = MachineLeaning_Predict_Rating_Hotel.predict_linear_regression_rating_hotel(model_lr, user_features_hotel_lr)
                st.write(f"Predicted Rating (Linear Regression) for User {selected_user_hotel}: {predicted_rating_lr}")
                st.write(f"Kết quả đánh giá mô hình:")
                MachineLeaning_Predict_Rating_Hotel.check_model(model_lr, X_test_lr, y_test_lr, 'Linear Regression')
                
            elif prediction_model == "Random Forest":
                model_rf, X_test_rf, y_test_rf = MachineLeaning_Predict_Rating_Hotel.train_random_forest_model_hotel()
                predicted_rating_rf = MachineLeaning_Predict_Rating_Hotel.predict_random_forest_rating_hotel(model_rf, user_features_hotel_lr)
                st.write(f"Predicted Rating (Random Forest) for User {selected_user_hotel}: {predicted_rating_rf}")
                st.write(f"Kết quả đánh giá mô hình:")
                MachineLeaning_Predict_Rating_Hotel.check_model(model_rf, X_test_rf, y_test_rf, 'Random Forest')
                
            elif prediction_model == "Neural Network":
                # Assuming you have loaded the neural network model somewhere in your project
                your_loaded_model = keras.models.load_model('/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/neural_model_hotel.h5')
                # Assuming you have combined_df loaded in your project
                your_combined_hotel_df = NeuralNetwork_Predict_Rating_Hotel.combined_df_hotel.copy()
                model_nn_hotel, X_test_nn, y_test_nn = NeuralNetwork_Predict_Rating_Hotel.train_neural_model_hotel(your_combined_hotel_df)
                predicted_rating_nn = NeuralNetwork_Predict_Rating_Hotel.predict_rating_for_user_hotel(selected_user_hotel, model_nn_hotel, your_combined_hotel_df)
                st.write(f"Predicted Rating (Neural Network) for User {selected_user_hotel}: {predicted_rating_nn}")
                st.write(f"Kết quả đánh giá mô hình:")
                NeuralNetwork_Predict_Rating_Hotel.evaluate_neural_model(model_nn_hotel, X_test_nn, y_test_nn, 'Neural Network')
                
        elif kind_predict == "Restaurant":
            if prediction_model == "Linear Regression":
                model_lr, X_test_lr, y_test_lr = MachineLeaning_Predict_Rating_Restaurant.train_linear_regression_model_restaurant()
                predicted_rating_lr = MachineLeaning_Predict_Rating_Restaurant.predict_linear_regression_rating_restaurant(model_lr, user_features_restaurant_lr)
                st.write(f"Predicted Rating (Linear Regression) for User {selected_user_restaurant}: {predicted_rating_lr}")
                st.write(f"Kết quả đánh giá mô hình:")
                MachineLeaning_Predict_Rating_Restaurant.check_model(model_lr, X_test_lr, y_test_lr, 'Linear Regression')
                
            elif prediction_model == "Random Forest":
                model_rf, X_test_rf, y_test_rf = MachineLeaning_Predict_Rating_Restaurant.train_random_forest_model_restaurant()
                predicted_rating_rf = MachineLeaning_Predict_Rating_Restaurant.predict_random_forest_rating_restaurant(model_rf, user_features_restaurant_lr)
                st.write(f"Predicted Rating (Random Forest) for User {selected_user_restaurant}: {predicted_rating_rf}")
                st.write(f"Kết quả đánh giá mô hình:")
                MachineLeaning_Predict_Rating_Restaurant.check_model(model_rf, X_test_rf, y_test_rf, 'Random Forest')
                
            elif prediction_model == "Neural Network":
                # Assuming you have loaded the neural network model somewhere in your project
                your_loaded_model = keras.models.load_model('/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/neural_model_restaurant.h5')
                # Assuming you have combined_df loaded in your project
                your_combined_restaurant_df = NeuralNetwork_Predict_Rating_Restaurant.combined_df_restaurant.copy()
                model_nn_restaurant, X_test_nn, y_test_nn = NeuralNetwork_Predict_Rating_Restaurant.train_neural_model_restaurant(your_combined_restaurant_df)
                predicted_rating_nn = NeuralNetwork_Predict_Rating_Restaurant.predict_rating_for_user_restaurant(selected_user_restaurant, model_nn_restaurant, your_combined_restaurant_df)
                st.write(f"Predicted Rating (Neural Network) for User {selected_user_restaurant}: {predicted_rating_nn}")
                st.write(f"Kết quả đánh giá mô hình:")
                NeuralNetwork_Predict_Rating_Restaurant.evaluate_neural_model(model_nn_restaurant, X_test_nn, y_test_nn, 'Neural Network')
                
        elif kind_predict == "Attraction":
            if prediction_model == "Linear Regression":
                model_lr, X_test_lr, y_test_lr = MachineLeaning_Predict_Rating_Attraction.train_linear_regression_model_attraction()
                predicted_rating_lr = MachineLeaning_Predict_Rating_Attraction.predict_linear_regression_rating_attraction(model_lr, user_features_attraction_lr)
                st.write(f"Predicted Rating (Linear Regression) for User {selected_user_attraction}: {predicted_rating_lr}")
                st.write(f"Kết quả đánh giá mô hình:")
                MachineLeaning_Predict_Rating_Attraction.check_model(model_lr, X_test_lr, y_test_lr, 'Linear Regression')
                
            elif prediction_model == "Random Forest":
                model_rf, X_test_rf, y_test_rf = MachineLeaning_Predict_Rating_Attraction.train_random_forest_model_attraction()
                predicted_rating_rf = MachineLeaning_Predict_Rating_Attraction.predict_random_forest_rating_attraction(model_rf, user_features_attraction_lr)
                st.write(f"Predicted Rating (Random Forest) for User {selected_user_attraction}: {predicted_rating_rf}")
                st.write(f"Kết quả đánh giá mô hình:")
                MachineLeaning_Predict_Rating_Attraction.check_model(model_rf, X_test_rf, y_test_rf, 'Random Forest')
                
            elif prediction_model == "Neural Network":
                # Assuming you have loaded the neural network model somewhere in your project
                your_loaded_model = keras.models.load_model('/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/neural_model_attraction.h5')
                # Assuming you have combined_df loaded in your project
                your_combined_attraction_df = NeuralNetwork_Predict_Rating_Attraction.combined_df_attraction.copy()
                model_nn_attraction, X_test_nn, y_test_nn = NeuralNetwork_Predict_Rating_Attraction.train_neural_model_attraction(your_combined_attraction_df)
                predicted_rating_nn = NeuralNetwork_Predict_Rating_Attraction.predict_rating_for_user_attraction(selected_user_attraction, model_nn_attraction, your_combined_attraction_df)
                st.write(f"Predicted Rating (Neural Network) for User {selected_user_attraction}: {predicted_rating_nn}")
                st.write(f"Kết quả đánh giá mô hình:")
                # Evaluate the model using X_test_nn and y_test_nn
                NeuralNetwork_Predict_Rating_Attraction.evaluate_neural_model(model_nn_attraction, X_test_nn, y_test_nn, 'Neural Network')
                

