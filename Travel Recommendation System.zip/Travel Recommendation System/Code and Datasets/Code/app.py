import streamlit as st
from ConDao import *

hotel_name = "An"
recommendations = user_based_cosine_recommendations(hotel_name)
st.text("Danh sách khách sạn được recommend:")
if len(recommendations) == 0:  # Check if recommendations list is empty
    st.text("Không có khách sạn được recommend.")
else:
    st.dataframe(recommendations)