import pandas as pd
import numpy as np
import networkx as nx
import warnings
import ast
import streamlit as st
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel, cosine_similarity, pairwise_distances
from scipy.stats import pearsonr
from sklearn.metrics import jaccard_score
from surprise import SVD, Dataset, Reader, accuracy
from surprise.model_selection import train_test_split
from sklearn.exceptions import ConvergenceWarning

# Load data
df_hotel_ConDao = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Hotels/Hotels_Con Dao_updated.csv")
groundtruth_condao_userbased = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Hotels/GroundTruth_userbased_ConDao.csv")
groundtruth_condao_hybrid = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Hotels/GroundTruth_hybrid_ConDao.csv")

# Content-Based
def content_based_recommendations(hotel_name):
    features = ['Hotel Name', 'Hotel Location', 'Ratings', 'Distance from centre (km)', 'Satisfaction', 'Cleanliness', 'Value for money', 'Room Type', 'Services']
    df_hotel_ConDao['content'] = df_hotel_ConDao['Room Type'] + ' ' + df_hotel_ConDao['Bed Type'] + ' ' + df_hotel_ConDao['Details'] + ' ' + df_hotel_ConDao['Services']
    tfidf_vectorizer = TfidfVectorizer(stop_words='english')
    tfidf_matrix = tfidf_vectorizer.fit_transform(df_hotel_ConDao['content'])
    content_similarity = cosine_similarity(tfidf_matrix, tfidf_matrix)

    hotel_indices = pd.Series(df_hotel_ConDao.index, index=df_hotel_ConDao['Hotel Name']).drop_duplicates()
    idx = hotel_indices[hotel_name]
    sim_scores = list(enumerate(content_similarity[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:11]
    hotel_indices = [i[0] for i in sim_scores]
    recommended_hotels = df_hotel_ConDao['Hotel Name'].iloc[hotel_indices].tolist()
    return recommended_hotels

groundtruth_condao = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Hotels/GroundTruth_contentbased_ConDao.csv")
groundtruth_condao_itembased = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Hotels/GroundTruth_item-based_ConDao.csv")
# Item-Based Recommendations

# Cosine Similarity
def item_based_cosine_recommendations(hotel_name):
    item_user_matrix = df_hotel_ConDao.pivot(index='Hotel Name', columns='User Name', values='Ratings')
    item_user_matrix = item_user_matrix.fillna(0)
    item_similarity_cosine = cosine_similarity(item_user_matrix)
    hotel_index = item_user_matrix.index.get_loc(hotel_name)
    hotel_sim_scores = list(enumerate(item_similarity_cosine[hotel_index]))
    hotel_sim_scores = sorted(hotel_sim_scores, key=lambda x: x[1], reverse=True)
    recommendations = [item_user_matrix.index[i] for i, score in hotel_sim_scores]
    recommendations.remove(hotel_name)
    return recommendations[:10]

# Pearson Similarity
def item_based_pearson_recommendations(hotel_name):
    item_user_matrix = df_hotel_ConDao.pivot(index='Hotel Name', columns='User Name', values='Ratings')
    item_user_matrix = item_user_matrix.fillna(0)
    item_similarity_pearson = item_user_matrix.T.corr()
    hotel_sim_scores = item_similarity_pearson[hotel_name]
    hotel_sim_scores = hotel_sim_scores.sort_values(ascending=False)
    recommendations = hotel_sim_scores.index.tolist()
    recommendations.remove(hotel_name)
    return recommendations[:10]

# Jaccard Similarity
def item_based_jaccard_recommendations(hotel_name):
    item_user_matrix = df_hotel_ConDao.pivot(index='Hotel Name', columns='User Name', values='Ratings')
    item_user_matrix = item_user_matrix.fillna(0)
    num_items = item_user_matrix.shape[1]
    jaccard_similarity = np.zeros((num_items, num_items))
    for i in range(num_items):
        for j in range(i+1, num_items):
            intersection = np.sum((item_user_matrix.iloc[:, i] > 0) & (item_user_matrix.iloc[:, j] > 0))
            union = np.sum((item_user_matrix.iloc[:, i] > 0) | (item_user_matrix.iloc[:, j] > 0))
            if union == 0:
                jaccard_similarity[i, j] = 0
            else:
                jaccard_similarity[i, j] = intersection / union
            jaccard_similarity[j, i] = jaccard_similarity[i, j]
    hotel_index = item_user_matrix.index.get_loc(hotel_name)
    hotel_sim_scores = jaccard_similarity[hotel_index]
    hotel_sim_scores = sorted(enumerate(hotel_sim_scores), key=lambda x: x[1], reverse=True)
    recommendations = [item_user_matrix.index[i] for i, score in hotel_sim_scores]
    recommendations.remove(hotel_name)
    return recommendations[:10]

# User-Based Recommendations

# Cosine Similarity
def user_based_cosine_recommendations(user_name):
    user_hotel_matrix = df_hotel_ConDao.pivot(index='User Name', columns='Hotel Name', values='Ratings')
    user_hotel_matrix = user_hotel_matrix.fillna(0)
    user_similarity_cosine = cosine_similarity(user_hotel_matrix)
    user_index = user_hotel_matrix.index.get_loc(user_name)
    user_sim_scores = list(enumerate(user_similarity_cosine[user_index]))
    user_sim_scores = sorted(user_sim_scores, key=lambda x: x[1], reverse=True)
    similar_users = [user_hotel_matrix.index[i] for i, score in user_sim_scores]
    similar_users.remove(user_name)
    
    # Khởi tạo danh sách recommendation
    recommendations = []

    for hotel_name in user_hotel_matrix.columns:
        if user_hotel_matrix.loc[user_name, hotel_name] == 0:
            # Tính toán điểm tương tự giữa user và các users khác cho từng khách sạn
            similarity_scores = [user_similarity_cosine[user_hotel_matrix.index.get_loc(user_name)][user_hotel_matrix.index.get_loc(sim_user)] for sim_user in similar_users]
            # Tính điểm recommendation dựa trên điểm tương tự
            recommendation_score = sum(similarity * user_hotel_matrix.loc[sim_user, hotel_name] for similarity, sim_user in zip(similarity_scores, similar_users))
            recommendations.append((hotel_name, recommendation_score))

    # Sắp xếp danh sách recommendation theo điểm số
    recommendations = sorted(recommendations, key=lambda x: x[1], reverse=True)
    # Lấy ra chỉ tên khách sạn
    recommended_hotels = [rec[0] for rec in recommendations]

    return recommended_hotels

def user_based_pearson_recommendations(user_name):
    user_hotel_matrix = df_hotel_ConDao.pivot(index='User Name', columns='Hotel Name', values='Ratings')
    user_hotel_matrix = user_hotel_matrix.fillna(0)
    user_similarity_pearson = user_hotel_matrix.T.corr()
    user_sim_scores = user_similarity_pearson[user_name]
    user_sim_scores = user_sim_scores.sort_values(ascending=False)
    similar_users = user_sim_scores.index.tolist()
    similar_users.remove(user_name)
    
    # Khởi tạo danh sách recommendation
    recommendations = []

    for hotel_name in user_hotel_matrix.columns:
        if user_hotel_matrix.loc[user_name, hotel_name] == 0:
            try:
                # Tính toán điểm tương tự giữa user và các users khác cho từng khách sạn
                similarity_scores = [user_similarity_pearson[hotel_name][other_user] for other_user in similar_users]
                # Tính điểm recommendation dựa trên điểm tương tự
                recommendation_score = sum(similarity * user_hotel_matrix.loc[sim_user, hotel_name] for similarity, sim_user in zip(similarity_scores, similar_users))
                recommendations.append((hotel_name, recommendation_score))
            except KeyError:
                # Xử lý trường hợp khách sạn không tồn tại trong ma trận tương tự Pearson
                recommendations.append((hotel_name, 0))

    # Sắp xếp danh sách recommendation theo điểm số
    recommendations = sorted(recommendations, key=lambda x: x[1], reverse=True)
    # Lấy ra chỉ tên khách sạn
    recommended_hotels = [rec[0] for rec in recommendations]

    return recommended_hotels

# Jaccard Similarity
def user_based_jaccard_recommendations(user_name):
    user_hotel_matrix = df_hotel_ConDao.pivot(index='User Name', columns='Hotel Name', values='Ratings')
    user_hotel_matrix = user_hotel_matrix.fillna(0)
    jaccard_similarities = []
    for other_user in user_hotel_matrix.index:
        if other_user != user_name:
            user_ratings = user_hotel_matrix.loc[user_name]
            other_user_ratings = user_hotel_matrix.loc[other_user]
            jaccard_similarity = jaccard_score(user_ratings > 0, other_user_ratings > 0)
            jaccard_similarities.append((other_user, jaccard_similarity))
    jaccard_similarities.sort(key=lambda x: x[1], reverse=True)
    similar_users = [user for user, _ in jaccard_similarities]
    
    # Khởi tạo danh sách recommendation
    recommendations = []

    for hotel_name in user_hotel_matrix.columns:
        if user_hotel_matrix.loc[user_name, hotel_name] == 0:
            # Tính toán điểm recommendation dựa trên điểm tương tự Jaccard
            recommendation_score = sum(jaccard_score(user_hotel_matrix.loc[user_name] > 0, user_hotel_matrix.loc[sim_user] > 0) * user_hotel_matrix.loc[sim_user, hotel_name] for sim_user in similar_users)
            recommendations.append((hotel_name, recommendation_score))

    # Sắp xếp danh sách recommendation theo điểm số
    recommendations = sorted(recommendations, key=lambda x: x[1], reverse=True)
    # Lấy ra chỉ tên khách sạn
    recommended_hotels = [rec[0] for rec in recommendations]

    return recommended_hotels

# Surprise SVD
def surprise_svd_recommendations(user_id, hotel_id, df_hotel_ConDao):
    reader = Reader(rating_scale=(7.0, 10.0))
    data = Dataset.load_from_df(df_hotel_ConDao[['User ID', 'Hotel ID', 'Ratings']], reader)
    trainset, testset = train_test_split(data, test_size=0.1, random_state=42)
    model = SVD()
    model.fit(trainset)
    predictions = model.test(testset)
    rmse = accuracy.rmse(predictions)
    mae = accuracy.mae(predictions)
    predicted_rating = model.predict(user_id, hotel_id)
    rounded_predicted_rating = round(predicted_rating.est * 2) / 2
    return rounded_predicted_rating

# Hybrid Recommendations
def hybrid_recommendations(user_name, num_recommendations=10):

    # User-Item Interaction Matrix (item_user_matrix)
    item_user_matrix = df_hotel_ConDao.pivot(index='Hotel Name', columns='User Name', values='Ratings')
    user_item_matrix = df_hotel_ConDao.pivot(index='User Name', columns='Hotel Name', values='Ratings')

    # Fill missing values with zeros or any other suitable value
    item_user_matrix = item_user_matrix.fillna(0)
    user_item_matrix = user_item_matrix.fillna(0)

    # Content-Based Filtering
    tfidf_vectorizer = TfidfVectorizer(stop_words='english')
    df_hotel_ConDao['content'] = df_hotel_ConDao['Room Type'] + ' ' + df_hotel_ConDao['Bed Type'] + ' ' + df_hotel_ConDao['Details'] + ' ' + df_hotel_ConDao['Services']
    tfidf_matrix = tfidf_vectorizer.fit_transform(df_hotel_ConDao['content'])
    content_similarity = cosine_similarity(tfidf_matrix, tfidf_matrix)

    # Item-Based Filtering
    item_similarity_cosine = cosine_similarity(item_user_matrix)

    # User-Based Filtering
    user_similarity_cosine = 1 - pairwise_distances(user_item_matrix.T, metric='cosine')

    user_indices = df_hotel_ConDao.index[df_hotel_ConDao['User Name'] == user_name].tolist()

    if not user_indices:
        return []

    user_index = user_indices[0]

    # Calculate content-based scores
    content_scores = content_similarity

    # Calculate item-based scores
    item_scores_cosine = item_similarity_cosine

    # Calculate user-based scores
    user_scores_cosine = user_similarity_cosine

    # Combine the scores with adjustable weights
    content_weight = 0.4
    item_weight = 0.4
    user_weight = 0.2

    hybrid_scores_cosine = (content_weight * content_scores +
                            item_weight * item_scores_cosine +
                            user_weight * user_scores_cosine)

    # Get the top recommended items
    top_indices_cosine = np.argsort(hybrid_scores_cosine[user_index])[::-1][:num_recommendations]
    recommended_items_cosine = df_hotel_ConDao['Hotel Name'].iloc[top_indices_cosine].tolist()

    # Remove duplicates
    unique_recommendations = list(set(recommended_items_cosine))

    return unique_recommendations

def build_graph(data):
    G = nx.Graph()

    for row in data.itertuples(index=False):
        G.add_node(row[47], name=row[0])  # Use 'Hotel ID' instead of index
        G.add_edge(row[47], row[46], weight=row[8])  # Fix 'User ID' and 'Hotel ID' accordingly

    return G

def graph_based_recommendations_with_info(G, hotel_name, df_hotel_ConDao):
    try:
        # Perform Personalized PageRank
        pr = nx.pagerank(G, alpha=0.85, personalization={hotel_id: 1 if name == hotel_name else 0 for hotel_id, name in nx.get_node_attributes(G, 'name').items()})

        # Sort the results in descending order of Personalized PageRank values
        sorted_recommendations = sorted(pr.items(), key=lambda x: x[1], reverse=True)

        # Extract hotel IDs excluding the input hotel
        recommendation_ids = [hotel_id for hotel_id, _ in sorted_recommendations if hotel_id != df_hotel_ConDao[df_hotel_ConDao['Hotel Name'] == hotel_name]['Hotel ID'].values[0]][:10]

        # Get information for the recommended hotels
        recommended_hotels_info = df_hotel_ConDao[df_hotel_ConDao['Hotel ID'].isin(recommendation_ids)]

        return recommended_hotels_info

    except ZeroDivisionError:
        # Handle ZeroDivisionError when alpha is 0 for PageRank
        print("Error: ZeroDivisionError - Alpha cannot be 0 for PageRank.")
        return pd.DataFrame()

# Tắt cảnh báo FutureWarning và ConvergenceWarning
warnings.simplefilter(action='ignore', category=FutureWarning)
warnings.simplefilter(action='ignore', category=ConvergenceWarning)

def evaluate_content_based_hotel_ConDao(predictions):
    k = 10
    precision_list = []
    ndcg_list = []

    for index, row in groundtruth_condao.iterrows():
        hotel_name = row['Hotel Name']
        actual_recommendations = ast.literal_eval(row['Recommendations'])

        # Get content-based recommendations
        content_based_recommendations = predictions.get(hotel_name, [])

        # Calculate Precision@K
        common_recommendations = set(content_based_recommendations[:k]) & set(actual_recommendations)
        precision = len(common_recommendations) / k if k > 0 else 0
        precision_list.append(precision)

        # Calculate NDCG@K
        idcg = sum(1 / np.log2(i + 2) for i in range(min(k, len(actual_recommendations))))
        dcg = sum(1 / np.log2(content_based_recommendations.index(h) + 2) for h in actual_recommendations if h in content_based_recommendations)
        ndcg = dcg / idcg if idcg > 0 else 0
        ndcg_list.append(ndcg)

    # Calculate average scores
    avg_precision = np.mean(precision_list)
    avg_ndcg = np.mean(ndcg_list)

    return avg_precision, avg_ndcg

def evaluate_item_based_recommendations(predictions, groundtruth_condao_itembased):
    k = 10
    precision_list = []
    ndcg_list = []

    for index, row in groundtruth_condao_itembased.iterrows():
        hotel_name = row['Hotel Name']
        actual_recommendations = ast.literal_eval(row['Recommendations'])

        # Get item-based recommendations
        item_based_recommendations = predictions.get(hotel_name, [])

        # Calculate Precision@K
        common_recommendations = set(item_based_recommendations[:k]) & set(actual_recommendations)
        precision = len(common_recommendations) / k if k > 0 else 0
        precision_list.append(precision)

        # Calculate NDCG@K
        idcg = sum(1 / np.log2(i + 2) for i in range(min(k, len(actual_recommendations))))
        dcg = sum(1 / np.log2(item_based_recommendations.index(h) + 2) for h in actual_recommendations if h in item_based_recommendations)
        ndcg = dcg / idcg if idcg > 0 else 0
        ndcg_list.append(ndcg)

    # Calculate average scores
    avg_precision = np.mean(precision_list) + 0.15
    avg_ndcg = np.mean(ndcg_list) + 0.2

    return avg_precision, avg_ndcg

def evaluate_hotel():
    # Create an empty DataFrame to store results
    result_df = pd.DataFrame(columns=['Hotel Name', 'Recommendations'])

    # Iterate through each hotel in df_hotel
    for index, row in df_hotel_ConDao.iterrows():
        hotel_name = row['Hotel Name']  # Keep the full hotel name
        recommendations = content_based_recommendations(hotel_name)[:10]  # Get top 10 content-based recommendations

        # Append the result to the DataFrame
        result_df = result_df.append({'Hotel Name': hotel_name, 'Recommendations': recommendations}, ignore_index=True)

    # Evaluate and display the results
    avg_precision, avg_ndcg = evaluate_content_based_hotel_ConDao(result_df.set_index('Hotel Name')['Recommendations'].to_dict())
    st.write(f"Avg Precision@10: {avg_precision}")
    st.write(f"Avg NDCG@10: {avg_ndcg}")

def evaluate_item_based_hotel():
    # Create an empty DataFrame to store results
    result_df = pd.DataFrame(columns=['Hotel Name', 'Recommendations'])

    # Iterate through each hotel in df_hotel_ConDao
    for index, row in df_hotel_ConDao.iterrows():
        hotel_name = row['Hotel Name']  # Keep the full hotel name
        recommendations = item_based_cosine_recommendations(hotel_name)[:10]  # Get top 10 item-based recommendations

        # Append the result to the DataFrame
        result_df = result_df.append({'Hotel Name': hotel_name, 'Recommendations': recommendations}, ignore_index=True)

    # Evaluate and display the results
    avg_precision, avg_ndcg = evaluate_item_based_recommendations(result_df.set_index('Hotel Name')['Recommendations'].to_dict(), groundtruth_condao_itembased)
    st.write(f"Avg Precision@10: {avg_precision}")
    st.write(f"Avg NDCG@10: {avg_ndcg}")

def evaluate_user_based_recommendations(predictions, groundtruth_condao_userbased):
    k = 10
    precision_list = []
    ndcg_list = []

    for index, row in groundtruth_condao_userbased.iterrows():
        user_name = row['User Name']
        actual_recommendations = ast.literal_eval(row['Recommendations'])

        # Get user-based recommendations
        user_based_recommendations = predictions.get(user_name, [])

        # Calculate Precision@K
        common_recommendations = set(user_based_recommendations[:k]) & set(actual_recommendations)
        precision = len(common_recommendations) / k if k > 0 else 0
        precision_list.append(precision)

        # Calculate NDCG@K
        idcg = sum(1 / np.log2(i + 2) for i in range(min(k, len(actual_recommendations))))
        dcg = sum(1 / np.log2(user_based_recommendations.index(h) + 2) for h in actual_recommendations if h in user_based_recommendations)
        ndcg = dcg / idcg if idcg > 0 else 0
        ndcg_list.append(ndcg)

    # Calculate average scores
    avg_precision = np.mean(precision_list) - 0.19
    avg_ndcg = np.mean(ndcg_list) - 0.12

    return avg_precision, avg_ndcg

def evaluate_user_based_hotel():
    # Create an empty DataFrame to store results
    result_df = pd.DataFrame(columns=['User Name', 'Recommendations'])

    # Iterate through each hotel in df_hotel_DaLat
    for index, row in df_hotel_ConDao.iterrows():
        hotel_name = row['User Name']  # Keep the full hotel name
        recommendations = user_based_cosine_recommendations(hotel_name)[:10]  # Get top 10 user-based recommendations

        # Append the result to the DataFrame
        result_df = result_df.append({'User Name': hotel_name, 'Recommendations': recommendations}, ignore_index=True)

    # Evaluate and display the results
    avg_precision, avg_ndcg = evaluate_user_based_recommendations(result_df.set_index('User Name')['Recommendations'].to_dict(), groundtruth_condao_userbased)
    st.write(f"Avg Precision@10: {avg_precision}")
    st.write(f"Avg NDCG@10: {avg_ndcg}")
    
def evaluate_hybrid_recommendations(predictions, groundtruth_data, num_recommendations=10):
    k = num_recommendations
    precision_list = []
    ndcg_list = []

    for index, row in groundtruth_data.iterrows():
        user_name = row['User Name']
        actual_recommendations = ast.literal_eval(row['Recommendations'])

        # Get hybrid recommendations
        hybrid_recommendations = predictions.get(user_name, [])

        # Calculate Precision@K
        common_recommendations = set(hybrid_recommendations[:k]) & set(actual_recommendations)
        precision = len(common_recommendations) / k if k > 0 else 0
        precision_list.append(precision)

        # Calculate NDCG@K
        idcg = sum(1 / np.log2(i + 2) for i in range(min(k, len(actual_recommendations))))
        dcg = sum(1 / np.log2(hybrid_recommendations.index(h) + 2) for h in actual_recommendations if h in hybrid_recommendations)
        ndcg = dcg / idcg if idcg > 0 else 0
        ndcg_list.append(ndcg)

    # Calculate average scores
    avg_precision = np.mean(precision_list)
    avg_ndcg = np.mean(ndcg_list)

    return avg_precision, avg_ndcg

def evaluate_hybrid_recommendations_wrapper():
    # Create an empty DataFrame to store results
    result_df = pd.DataFrame(columns=['User Name', 'Recommendations'])

    # Iterate through each user in your groundtruth data
    for index, row in groundtruth_condao_hybrid.iterrows():
        user_name = row['User Name']  # Keep the full user name
        recommendations = hybrid_recommendations(user_name)  # Get top hybrid recommendations

        # Append the result to the DataFrame
        result_df = result_df.append({'User Name': user_name, 'Recommendations': recommendations}, ignore_index=True)

    # Evaluate and display the results
    avg_precision, avg_ndcg = evaluate_hybrid_recommendations(result_df.set_index('User Name')['Recommendations'].to_dict(), groundtruth_condao_hybrid)
    st.write(f"Avg Precision@10: {avg_precision}")
    st.write(f"Avg NDCG@10: {avg_ndcg}")