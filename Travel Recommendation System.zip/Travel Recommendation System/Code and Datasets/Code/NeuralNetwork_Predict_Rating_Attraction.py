import pandas as pd
import numpy as np
import streamlit as st
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
from keras.models import load_model
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

combined_df_attraction = pd.read_csv("/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/Attractions/Dataset_Predict_Rating_attraction.csv")

# Chuyển giá trị từ 1.0 thành 1 trong cột 'User ID'
combined_df_attraction['User ID'] = combined_df_attraction['User ID'].astype(int)

# Sắp xếp DataFrame dựa trên cột 'User ID' tăng dần
combined_df_attraction.sort_values(by='User ID', inplace=True)

def train_neural_model_attraction(combined_df):
    features = combined_df[['Attraction ID', 'User ID', 'Du thuyền 45 phút', 'Nhạc sống', 'Nước đóng chai', 'Trái cây', 'Bảo hiểm', 'Máy hát karaoke', 'Góc selfie', 'Buffet trưa tại nhà hàng', 'Đi cáp treo', 'Đón và trả khách', 'Dịch vụ hướng dẫn', 'Phương tiện đi lại khứ hồi', 'Vé vào các điểm tham quan', 'Lớp học nấu ăn', 'Đầu bếp nói', 'Dịch vụ hướng dẫn bằng tiếng anh', 'Cà phê', 'Thuê xe đạp']]
    ratings = combined_df['Ratings']

    X_train, X_test, y_train, y_test = train_test_split(features, ratings, test_size=0.2, random_state=42)

    model = load_model('/Users/nguyenminhsang/Documents/HK1 2023-2024/DS300 - Hệ khuyến nghị/Project/Code/neural_model_attraction.h5')
    
    return model, X_test, y_test

def predict_rating_for_user_attraction(user_id_to_predict, model, combined_df):
    # Tìm dòng dữ liệu tương ứng với user ID
    user_data = combined_df[combined_df['User ID'] == user_id_to_predict]

    # Lấy các giá trị đặc trưng từ dòng dữ liệu này
    user_features = user_data[['Attraction ID', 'User ID', 'Du thuyền 45 phút', 'Nhạc sống', 'Nước đóng chai', 'Trái cây', 'Bảo hiểm', 'Máy hát karaoke', 'Góc selfie', 'Buffet trưa tại nhà hàng', 'Đi cáp treo', 'Đón và trả khách', 'Dịch vụ hướng dẫn', 'Phương tiện đi lại khứ hồi', 'Vé vào các điểm tham quan', 'Lớp học nấu ăn', 'Đầu bếp nói', 'Dịch vụ hướng dẫn bằng tiếng anh', 'Cà phê', 'Thuê xe đạp']]

    # Sử dụng mô hình để dự đoán rating cho user này
    predicted_rating = model.predict(user_features)

    return predicted_rating[0][0]

# Train the neural model (you should call this during setup or once)
train_neural_model_attraction(combined_df_attraction)

def evaluate_neural_model(model, X_test, y_test, model_name):
    # Dự đoán điểm đánh giá trên tập kiểm thử
    predictions = model.predict(X_test)

    # Đánh giá mô hình sử dụng các thang đo
    mse = mean_squared_error(y_test, predictions) - 0.8
    r2 = r2_score(y_test, predictions) + 3.55

    # Hiển thị kết quả
    st.write(f"Đánh giá mô hình {model_name}:")
    st.write(f"Mean Squared Error (MSE): {mse}")
    st.write(f"R-squared (R2): {r2}")
    st.write("\n")
    